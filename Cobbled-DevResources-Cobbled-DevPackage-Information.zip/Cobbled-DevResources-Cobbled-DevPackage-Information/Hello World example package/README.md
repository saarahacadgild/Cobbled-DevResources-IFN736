# Cobbled HLO local developer package

This package is a runnable read/write reference implementation. It teaches the
same boundary used by a Cobbled User Application service:

`Bearer runtime JWT → validation → exact ABAC permission → SESSION_CONTEXT → fixed stored procedure → JSON`

It is for a developer's own machine only. It does not install through Module
Management and cannot access a Cobbled environment, live databases, or Auth0.

## Contents

- `Cobbled.Hlo.Local.sln` — Visual Studio solution.
- `src/Cobbled.Hlo.LocalApi` — API validating a Cobbled-style runtime JWT.
- `tools/Cobbled.Hlo.LocalToken` — development-only command-line token issuer.
- `database/local` — local database install, seed, and verification scripts.
- `contracts`, `samples`, and `docs` — API contract and security walkthrough.

## Install

1. Create `Cobbled_HLO_Local` in SQL Server/LocalDB.
2. Run `database/local/01-install.sql`, `02-seed.sql`, then `03-verify.sql`.
3. Set a random base64 signing key in user secrets; do not commit it:

```powershell
dotnet user-secrets --project src/Cobbled.Hlo.LocalApi set "HloSecurity:LocalSigningKeyBase64" "<32-random-bytes-as-base64>"
dotnet user-secrets --project tools/Cobbled.Hlo.LocalToken set "HloSecurity:LocalSigningKeyBase64" "<the-same-value>"
```

4. Start the API with `dotnet run --project src/Cobbled.Hlo.LocalApi`.
5. Mint a short-lived local development token with the token CLI, then call the
   documented `GET` and `PUT` endpoints.

Read [docs/developer-guide.md](docs/developer-guide.md) before copying this
pattern into a module. In production, the token comes from the Application
Plane identity-context service after Auth0 login; an application module never
implements login or mints its own token.
