USE [Cobbled_HLO_Local];
GO
SET XACT_ABORT ON;
GO
IF SCHEMA_ID(N'hlo') IS NULL EXEC(N'CREATE SCHEMA hlo AUTHORIZATION dbo;');
GO
IF OBJECT_ID(N'hlo.hlo_Greeting', N'U') IS NULL
CREATE TABLE hlo.hlo_Greeting
(
 GreetingID char(32) NOT NULL CONSTRAINT PK_hlo_Greeting PRIMARY KEY,
 TenantID char(32) NOT NULL,
 GreetingText nvarchar(200) NOT NULL,
 CreatedByMemberID char(32) NOT NULL,
 UpdatedByMemberID char(32) NOT NULL,
 CreatedUtc datetime2(7) NOT NULL CONSTRAINT DF_hlo_Greeting_CreatedUtc DEFAULT SYSUTCDATETIME(),
 UpdatedUtc datetime2(7) NOT NULL CONSTRAINT DF_hlo_Greeting_UpdatedUtc DEFAULT SYSUTCDATETIME(),
 CONSTRAINT UX_hlo_Greeting_Tenant UNIQUE (TenantID)
);
GO
CREATE OR ALTER FUNCTION hlo.hlo_TenantPredicate(@TenantID char(32)) RETURNS TABLE WITH SCHEMABINDING AS RETURN
 SELECT 1 AS hlo_TenantPredicateResult WHERE @TenantID = CONVERT(char(32), SESSION_CONTEXT(N'TenantID'));
GO
IF NOT EXISTS (SELECT 1 FROM sys.security_policies WHERE name=N'hlo_TenantPolicy')
CREATE SECURITY POLICY hlo.hlo_TenantPolicy ADD FILTER PREDICATE hlo.hlo_TenantPredicate(TenantID) ON hlo.hlo_Greeting, ADD BLOCK PREDICATE hlo.hlo_TenantPredicate(TenantID) ON hlo.hlo_Greeting AFTER INSERT, ADD BLOCK PREDICATE hlo.hlo_TenantPredicate(TenantID) ON hlo.hlo_Greeting AFTER UPDATE WITH (STATE=ON);
GO
CREATE OR ALTER PROCEDURE hlo.hlo_Greeting_CRUD_JSON @Action varchar(10), @Payload nvarchar(max)=NULL AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 DECLARE @TenantID char(32)=CONVERT(char(32),SESSION_CONTEXT(N'TenantID')), @MemberID char(32)=CONVERT(char(32),SESSION_CONTEXT(N'MemberID'));
 IF @TenantID IS NULL OR @MemberID IS NULL THROW 52901,'Trusted runtime context is required.',1;
 SET @Action=UPPER(@Action);
 IF @Action='SELECT' BEGIN SELECT (SELECT GreetingText,UpdatedUtc FROM hlo.hlo_Greeting WHERE TenantID=@TenantID FOR JSON PATH,WITHOUT_ARRAY_WRAPPER) AS JsonPayload; RETURN; END;
 IF @Action<>'UPSERT' OR ISJSON(@Payload)<>1 THROW 52902,'Action must be SELECT or UPSERT with valid JSON.',1;
 DECLARE @GreetingText nvarchar(200)=NULLIF(LTRIM(RTRIM(JSON_VALUE(@Payload,'$.GreetingText'))),N'');
 IF @GreetingText IS NULL THROW 52903,'GreetingText is required.',1;
 MERGE hlo.hlo_Greeting AS target USING (SELECT @TenantID TenantID) source ON target.TenantID=source.TenantID
 WHEN MATCHED THEN UPDATE SET GreetingText=@GreetingText,UpdatedByMemberID=@MemberID,UpdatedUtc=SYSUTCDATETIME()
 WHEN NOT MATCHED THEN INSERT(GreetingID,TenantID,GreetingText,CreatedByMemberID,UpdatedByMemberID) VALUES(CONVERT(char(32),REPLACE(CONVERT(char(36),NEWID()),'-','')),@TenantID,@GreetingText,@MemberID,@MemberID);
 SELECT (SELECT GreetingText,UpdatedUtc FROM hlo.hlo_Greeting WHERE TenantID=@TenantID FOR JSON PATH,WITHOUT_ARRAY_WRAPPER) AS JsonPayload;
END;
GO
IF NOT EXISTS(SELECT 1 FROM sys.database_principals WHERE name=N'hlo_runtime') CREATE ROLE hlo_runtime;
DENY SELECT,INSERT,UPDATE,DELETE ON OBJECT::hlo.hlo_Greeting TO public;
GRANT EXECUTE ON OBJECT::hlo.hlo_Greeting_CRUD_JSON TO hlo_runtime;
PRINT 'PASS: HLO local RLS database installed.';
