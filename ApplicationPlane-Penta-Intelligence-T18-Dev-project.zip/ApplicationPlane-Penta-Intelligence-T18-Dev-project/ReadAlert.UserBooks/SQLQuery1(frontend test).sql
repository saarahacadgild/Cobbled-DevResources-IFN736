USE Cobbled_NoRLS;
GO

INSERT INTO ral.ral_Books (TenantID, BookID, BookTitle, ISBN13, IsActive, CreatedUtc)
VALUES (
    'F115B0A094467E7FCBA8DB16DF52242E',
    '30000000000000000000000000000099',
    'Test Book For Frontend',
    '9781234567890',
    1,
    SYSUTCDATETIME()
);