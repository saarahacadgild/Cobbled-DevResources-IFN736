// ReadAlert UserBooks: reading-record microservice, adapted from the EDP reference module.
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using System.Text.Json;
using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddCors(o => o.AddDefaultPolicy(p => p
    .WithOrigins(builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? ["http://localhost:5173"])
    .AllowAnyHeader().AllowAnyMethod()));
var app = builder.Build();
app.UseCors();

var connectionString = app.Configuration.GetConnectionString("CobbledData")
    ?? throw new InvalidOperationException("ConnectionStrings:CobbledData is required.");

// Health stays unauthenticated; used to distinguish a down service from a valid
// request the user simply cannot perform.
app.MapGet("/api/ral/v01/user-books/health", () => Results.Ok(new { service = "ReadAlert.UserBooks", version = "1.0.0", status = "healthy" }));
app.MapGet("/api/ral/v01/user-books/readiness", async () =>
{
    try
    {
        await using var db = new SqlConnection(connectionString);
        await db.OpenAsync();
        var ready = Convert.ToInt32(await new SqlCommand(
            "SELECT IIF(OBJECT_ID(N'ral.ral_UserBooks_CRUD_JSON',N'P') IS NULL,0,1)", db).ExecuteScalarAsync()) == 1;
        return ready ? Results.Ok(new { status = "ready" }) : Results.StatusCode(503);
    }
    catch { return Results.StatusCode(503); }
});

// GET current member's reading records.
app.MapGet("/api/ral/v01/user-books", async (HttpRequest request) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);
    if (scope is null) return Results.Unauthorized();
    if (!scope.Has("ral.user-books.read")) return Forbidden("ral.user-books.read");
    return Json(await ExecuteCrudAsync(connectionString, scope, "SELECT", new { MemberID = scope.MemberId }));
});

// POST add/upsert a book-read record.
app.MapPost("/api/ral/v01/user-books", async (HttpRequest request, UserBookInput input) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);
    if (scope is null) return Results.Unauthorized();
    if (!scope.Has("ral.user-books.write")) return Forbidden("ral.user-books.write");
    if (string.IsNullOrWhiteSpace(input.BookID)) return Results.BadRequest(new { code = "RAL_BOOKID_REQUIRED" });

    return Json(await ExecuteCrudAsync(connectionString, scope, "INSERT", new
    {
        BookID = input.BookID,
        ReadingStatusCode = input.ReadingStatusCode ?? "READ",
        StartedDate = input.StartedDate,
        FinishedDate = input.FinishedDate,
        Rating = input.Rating,
        ReviewText = input.ReviewText?.Trim(),
        PrivateNote = input.PrivateNote?.Trim(),
        SourceCode = input.SourceCode ?? "MANUAL"
    }), 201);
});

// PUT update an existing reading record (status, dates, rating, notes).
app.MapPut("/api/ral/v01/user-books/{userBookId}", async (HttpRequest request, string userBookId, UserBookInput input) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);
    if (scope is null) return Results.Unauthorized();
    if (!scope.Has("ral.user-books.write")) return Forbidden("ral.user-books.write");
    if (userBookId.Length != 32) return Results.BadRequest(new { code = "RAL_INPUT_INVALID" });

    return Json(await ExecuteCrudAsync(connectionString, scope, "UPDATE", new
    {
        UserBookID = userBookId,
        ReadingStatusCode = input.ReadingStatusCode,
        StartedDate = input.StartedDate,
        FinishedDate = input.FinishedDate,
        Rating = input.Rating,
        ReviewText = input.ReviewText?.Trim(),
        PrivateNote = input.PrivateNote?.Trim(),
        SourceCode = input.SourceCode
    }));
});

// DELETE soft-deactivates a reading record.
app.MapDelete("/api/ral/v01/user-books/{userBookId}", async (HttpRequest request, string userBookId) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);
    if (scope is null) return Results.Unauthorized();
    if (!scope.Has("ral.user-books.delete")) return Forbidden("ral.user-books.delete");
    return Json(await ExecuteCrudAsync(connectionString, scope, "DELETE", new { UserBookID = userBookId }));
});

// TEMP: local test-token generator. Remove before real MMS login is wired up.
if (app.Environment.IsDevelopment())
{
    app.MapPost("/api/ral/v01/user-books/dev-token", () =>
    {
        var key = app.Configuration["RalSecurity:SigningKeyBase64"];
        var now = DateTime.UtcNow;
        var token = new JwtSecurityToken(
            app.Configuration["RalSecurity:Issuer"],
            app.Configuration["RalSecurity:Audience"],
            [
                new("tenant_id", "F115B0A094467E7FCBA8DB16DF52242E"),
                new("member_id", "00000000000000000000000000000001"),
                new("permissions", "ral.user-books.read"),
                new("permissions", "ral.user-books.write"),
                new("permissions", "ral.user-books.delete")
            ],
            now, now.AddHours(2),
            new SigningCredentials(new SymmetricSecurityKey(Convert.FromBase64String(key!)), SecurityAlgorithms.HmacSha256));
        return Results.Ok(new { token = new JwtSecurityTokenHandler().WriteToken(token) });
    });
}

app.Run();

static async Task<RalScope?> ReadScopeAsync(HttpRequest request, IConfiguration configuration)
{
    try
    {
        var header = request.Headers.Authorization.ToString();
        if (!header.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)) return null;
        var key = configuration["RalSecurity:SigningKeyBase64"];
        if (string.IsNullOrWhiteSpace(key)) return null;
        var result = await new JsonWebTokenHandler().ValidateTokenAsync(header[7..], new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = configuration["RalSecurity:Issuer"],
            ValidateAudience = true,
            ValidAudience = configuration["RalSecurity:Audience"],
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Convert.FromBase64String(key)),
            ClockSkew = TimeSpan.FromSeconds(30)
        });
        if (!result.IsValid || result.ClaimsIdentity is null) return null;
        string? Claim(string name) => result.ClaimsIdentity.Claims.FirstOrDefault(c => c.Type == name)?.Value;
        var tenantId = Claim("tenant_id");
        var memberId = Claim("member_id");
        if (tenantId?.Length != 32 || memberId?.Length != 32) return null;
        return new RalScope(tenantId, memberId, result.ClaimsIdentity.Claims
            .Where(c => c.Type == "permissions").Select(c => c.Value).ToHashSet(StringComparer.OrdinalIgnoreCase));
    }
    catch { return null; }
}

static async Task<string> ExecuteCrudAsync(string connectionString, RalScope scope, string action, object payload)
{
    await using var db = new SqlConnection(connectionString);
    await db.OpenAsync();

    // Tenant/member values originate in the signed context, never the request body.
    foreach (var pair in new[] { ("TenantID", scope.TenantId), ("MemberID", scope.MemberId) })
    {
        await using var command = new SqlCommand("EXEC sys.sp_set_session_context @key,@value", db);
        command.Parameters.AddWithValue("@key", pair.Item1);
        command.Parameters.AddWithValue("@value", pair.Item2);
        await command.ExecuteNonQueryAsync();
    }

    await using var crud = new SqlCommand("ral.ral_UserBooks_CRUD_JSON", db) { CommandType = CommandType.StoredProcedure };
    crud.Parameters.AddWithValue("@Action", action);
    crud.Parameters.Add("@Payload", SqlDbType.NVarChar, -1).Value = JsonSerializer.Serialize(payload);
    // ral_UserBooks_CRUD_JSON returns its JSON via an OUTPUT parameter, unlike EDP's ExecuteScalar pattern.
    var resultParam = crud.Parameters.Add("@Result", SqlDbType.NVarChar, -1);
    resultParam.Direction = ParameterDirection.Output;

    await crud.ExecuteNonQueryAsync();
    return resultParam.Value?.ToString() ?? "{}";
}

static IResult Forbidden(string permission) => Results.Json(new { code = "RAL_PERMISSION_REQUIRED", requiredPermission = permission }, statusCode: 403);
static IResult Json(string body, int statusCode = 200) => Results.Text(body, "application/json", Encoding.UTF8, statusCode);

record RalScope(string TenantId, string MemberId, HashSet<string> Permissions) { public bool Has(string permission) => Permissions.Contains(permission); }
record UserBookInput(string? BookID, string? ReadingStatusCode, string? StartedDate, string? FinishedDate, int? Rating, string? ReviewText, string? PrivateNote, string? SourceCode);
