# ReadAlert — Reading Record Module (User Books)

Part of the ReadAlert Delivery 1 microservices for the Cobble platform. This module lets a member track the books they want to read, are currently reading, or have finished — including status, dates, rating, and review notes.

## Architecture

Three-layer design, matching Cobble's standard pattern:

```
Frontend (HTML/JS) → JSON → API (ASP.NET Core) → JSON → Stored Procedure (SQL Server)
```

- No layer talks directly to the database except through the stored procedure.
- Tenant and member identity come only from the signed JWT — never from the request body.
- Adapted from Wayne's EDP (Example Dev Product) reference module.

## Folder structure

```
ReadAlert.UserBooks/
├── api/                        # ASP.NET Core minimal API
│   ├── Program.cs
│   ├── ReadAlert.UserBooks.Api.csproj
│   └── appsettings.Development.json
├── database/
│   └── no-rls/
│       └── build.sql           # Creates ral schema, all 6 Delivery 1 tables, all 10 stored procedures
├── frontend/
│   └── index.html   # Simple grid + add-book form, talks to the API
├── SQLQuery1(frontend test).sql       # Manually adds one extra test book for frontend demoing
├── SQLQuery7.sql                      # Wayne's official Delivery 1 seed/test data
└── ReadAlert.UserBooks.sln
```

## Prerequisites

- SQL Server (Express is fine) with a local instance, e.g. `localhost\SQLEXPRESS`
- .NET 8 SDK
- A modern browser
- Python (for serving the frontend locally — any simple HTTP server works)

## Setup — first time

1. **Create the database**
   ```sql
   CREATE DATABASE Cobbled_NoRLS;
   ```
2. **Run `database/no-rls/build.sql`** against `Cobbled_NoRLS` — creates the `ral` schema, all 6 tables, and all 10 stored procedures.
3. **Run `SQLQuery7.sql`** — seeds Wayne's official Delivery 1 test data (sample tenants, members, authors, books).
4. *(Optional)* Run `SQLQuery1(frontend test).sql` — adds one extra test book if you want a clean book to test the "add" flow without hitting the unique-constraint conflict on already-seeded books.
5. **Update `api/appsettings.Development.json`** — set `ConnectionStrings:CobbledData` to match your local SQL Server instance name.

## Running the API

```powershell
cd api
$env:ASPNETCORE_ENVIRONMENT="Development"
dotnet run
```

API will listen on `http://localhost:5000`.

## Running the frontend

The frontend must be served over `http://`, not opened directly as a `file://` path, or the browser's CORS policy will block requests to the API.

```powershell
cd frontend
python -m http.server 5173
```

Then open `http://localhost:5173/index.html`.

## API endpoints

| Method | Route | Description |
|---|---|---|
| GET | `/api/ral/v01/user-books/health` | Health check (unauthenticated) |
| GET | `/api/ral/v01/user-books/readiness` | Confirms the stored procedure exists |
| POST | `/api/ral/v01/user-books/dev-token` | **Dev only** — issues a test JWT (tenant/member hardcoded to Wayne's seed data). Remove once real MMS login is wired up. |
| GET | `/api/ral/v01/user-books` | Returns the current member's reading records |
| POST | `/api/ral/v01/user-books` | Adds a book to the member's reading list |
| PUT | `/api/ral/v01/user-books/{userBookId}` | Updates status, dates, rating, or review |
| DELETE | `/api/ral/v01/user-books/{userBookId}` | Soft-deactivates a reading record (`IsActive = 0`) |

All endpoints except `/health`, `/readiness`, and `/dev-token` require `Authorization: Bearer <token>`.

## Known rules / constraints

- Every `BookID` used must already exist in `ral_Books` for the same `TenantID` (foreign key).
- A member can only have one entry per book (`UQ_ral_UserBooks_Member_Book` unique constraint) — attempting to add a duplicate returns a SQL error, by design.
- Deletes are soft (row stays, `IsActive` flips to `false`) so reading history isn't lost.

## Status

- Database, stored procedures, and API fully built and tested (GET/POST/PUT/DELETE all verified via Postman)
- Basic frontend built and tested end-to-end
- Not yet connected to the real Books module (Julia) or real MMS login — currently uses Wayne's seed data and a dev-only test token