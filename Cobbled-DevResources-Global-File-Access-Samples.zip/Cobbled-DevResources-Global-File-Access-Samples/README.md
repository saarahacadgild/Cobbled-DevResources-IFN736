# Cobbled GLB local developer package

This package gives a developer a private GLB service on their own machine. It
does **not** grant access to Cobbled shared/live GLB databases, internal
endpoints, management operations, or credentials.

## What is included

- `Cobbled.Glb.Local.sln` — open this in Visual Studio 2022 or later.
- `database/local/01-install.sql` — creates the database objects, least
  privilege database roles, and read stored procedures.
- `database/local/02-seed.sql` — small local-only lookup data set.
- `src/Cobbled.Glb.LocalApi` — API service exposing the public GLB v10 read
  contract.
- `docker-compose.yml` — optional local SQL Server and API runtime.
- `contracts/openapi-glb-v10.yaml` and `samples/` — calling contract/examples.

## Prerequisites

- .NET SDK 10.0 or later.
- SQL Server 2022 Developer Edition / LocalDB, or Docker Desktop.
- `sqlcmd` if installing against a local SQL Server directly.

## Fast start with Docker

1. Copy `.env.example` to `.env` and replace `change-this-local-key` with a
   random value. Never commit `.env`.
2. Run `docker compose up --build` from this folder.
3. The API is available at `http://localhost:5088`.
4. Call the API using the development key. Examples are in `samples/`.

Docker executes the install and seed scripts automatically when it creates the
database volume for the first time. To reset a **local-only** test database,
run `docker compose down -v` and start again.

## Install against an existing local SQL Server

Create a database named `Cobbled_GLB_Local`, then run the scripts in order:

```powershell
sqlcmd -S localhost -E -Q "CREATE DATABASE [Cobbled_GLB_Local]"
sqlcmd -S localhost -E -d Cobbled_GLB_Local -b -i database/local/01-install.sql
sqlcmd -S localhost -E -d Cobbled_GLB_Local -b -i database/local/02-seed.sql
```

Set `ConnectionStrings__Glb` and `GLB__DeveloperApiKey` in
`src/Cobbled.Glb.LocalApi/appsettings.Development.json` or user secrets, then
run `dotnet run --project src/Cobbled.Glb.LocalApi`.

## Calling rules

Every request requires `X-GLB-Development-Key` equal to the configured local
key. This is intentionally a local development guard, not a production
identity mechanism. Production uses a signed Cobbled runtime context and the
`glb.lookups.read` ABAC permission.

Only these public endpoints exist:

```http
GET /AppPlane/glb/v10/types
GET /AppPlane/glb/v10/lookups?type=Country
```

Do not use a database connection from an application module. Do not call a
stored procedure directly. The local API connects using the restricted
`glb_runtime` role and calls the read procedures only.

See [docs/developer-guide.md](docs/developer-guide.md) for C# and TypeScript
examples, response/error meanings, and production integration rules.
